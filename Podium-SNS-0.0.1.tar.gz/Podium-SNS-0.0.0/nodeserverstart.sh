#!/bin/sh
npm install cookie
npm install winston
npm install express
npm install socket.io