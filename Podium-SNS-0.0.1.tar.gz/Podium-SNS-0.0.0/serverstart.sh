#!/bin/sh
virtual/bin/python manage.py runserver 8000